# Claude AI Crypto Trading Bot

Automated crypto trading bot powered by Claude AI, connected to Coinbase Advanced, hosted 24/7 on Railway.

## Setup Instructions

### 1. Environment Variables (add these in Railway dashboard)

| Variable | Value | Description |
|---|---|---|
| COINBASE_API_KEY | your key | From Coinbase Advanced API settings |
| COINBASE_API_SECRET | your secret | From Coinbase Advanced API settings |
| ANTHROPIC_API_KEY | your key | From platform.anthropic.com |
| TRADE_BUDGET | 500 | Your starting budget in USD |
| RISK_PER_TRADE | 0.12 | 12% of budget per trade |
| CHECK_INTERVAL | 300 | Seconds between analysis (300 = 5 min) |
| PAPER_MODE | true | Set to false to go LIVE |

### 2. Deploy to Railway

1. Push this folder to a GitHub repo
2. In Railway: New Project → Deploy from GitHub
3. Select your repo
4. Add the environment variables above
5. Deploy — bot starts automatically

### 3. Going Live

- Test in PAPER_MODE=true for a few days first
- Watch the Railway logs to see Claude's decisions
- When confident, set PAPER_MODE=false
- Start small — never risk more than you can afford to lose

## Coins Traded
- BTC-USD
- ETH-USD  
- SOL-USD

## Strategy
Claude AI analyzes EMA 9/21 crossovers and RSI every 5 minutes.
Moderate risk profile — 12% of budget per trade maximum.
