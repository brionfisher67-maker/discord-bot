import os
import time
import hmac
import hashlib
import json
import requests
from datetime import datetime
from anthropic import Anthropic

# ── Config from environment variables ──────────────────────────────────────────
COINBASE_API_KEY    = os.environ.get("COINBASE_API_KEY", "")
COINBASE_API_SECRET = os.environ.get("COINBASE_API_SECRET", "")
ANTHROPIC_API_KEY   = os.environ.get("ANTHROPIC_API_KEY", "")
TRADE_BUDGET        = float(os.environ.get("TRADE_BUDGET", "500"))
RISK_PER_TRADE      = float(os.environ.get("RISK_PER_TRADE", "0.12"))   # 12% per trade
CHECK_INTERVAL      = int(os.environ.get("CHECK_INTERVAL", "300"))       # 5 minutes
PAPER_MODE          = os.environ.get("PAPER_MODE", "true").lower() == "true"

COINS = ["BTC-USD", "ETH-USD", "SOL-USD"]

client = Anthropic(api_key=ANTHROPIC_API_KEY)

# ── Coinbase Advanced API ───────────────────────────────────────────────────────
def coinbase_headers(method, path, body=""):
    timestamp = str(int(time.time()))
    message   = timestamp + method.upper() + path + body
    signature = hmac.new(
        COINBASE_API_SECRET.encode("utf-8"),
        message.encode("utf-8"),
        digestmod=hashlib.sha256
    ).hexdigest()
    return {
        "CB-ACCESS-KEY":       COINBASE_API_KEY,
        "CB-ACCESS-SIGN":      signature,
        "CB-ACCESS-TIMESTAMP": timestamp,
        "Content-Type":        "application/json",
    }

def get_price(product_id):
    path = f"/api/v3/brokerage/products/{product_id}"
    headers = coinbase_headers("GET", path)
    r = requests.get(f"https://api.coinbase.com{path}", headers=headers, timeout=10)
    data = r.json()
    return float(data.get("price", 0))

def get_candles(product_id, granularity="FIVE_MINUTE", limit=20):
    path = f"/api/v3/brokerage/products/{product_id}/candles?granularity={granularity}&limit={limit}"
    headers = coinbase_headers("GET", path)
    r = requests.get(f"https://api.coinbase.com{path}", headers=headers, timeout=10)
    return r.json().get("candles", [])

def place_order(product_id, side, usd_amount):
    if PAPER_MODE:
        log(f"[PAPER] {side} ${usd_amount:.2f} of {product_id}")
        return {"paper": True, "side": side, "amount": usd_amount}
    path = "/api/v3/brokerage/orders"
    body = json.dumps({
        "client_order_id": f"bot-{int(time.time())}",
        "product_id": product_id,
        "side": side,
        "order_configuration": {
            "market_market_ioc": {
                "quote_size": str(round(usd_amount, 2))
            }
        }
    })
    headers = coinbase_headers("POST", path, body)
    r = requests.post(f"https://api.coinbase.com{path}", headers=headers, data=body, timeout=10)
    return r.json()

# ── Claude AI Analysis ──────────────────────────────────────────────────────────
def analyze_with_claude(coin, price, candles):
    closes = [float(c.get("close", 0)) for c in candles if c.get("close")]
    if len(closes) < 5:
        return "hold", "Not enough data."

    ema9  = sum(closes[-9:])  / min(9,  len(closes))
    ema21 = sum(closes[-21:]) / min(21, len(closes))

    highs  = [float(c.get("high",  price)) for c in candles]
    lows   = [float(c.get("low",   price)) for c in candles]
    gains  = [max(0, closes[i] - closes[i-1]) for i in range(1, len(closes))]
    losses = [max(0, closes[i-1] - closes[i]) for i in range(1, len(closes))]
    avg_gain = sum(gains[-14:])  / 14 if len(gains)  >= 14 else sum(gains)  / max(len(gains), 1)
    avg_loss = sum(losses[-14:]) / 14 if len(losses) >= 14 else sum(losses) / max(len(losses), 1)
    rsi = 100 - (100 / (1 + avg_gain / avg_loss)) if avg_loss > 0 else 100

    prompt = f"""You are an expert crypto trader analyzing {coin}.

Current price: ${price:,.4f}
EMA 9:  ${ema9:,.4f}
EMA 21: ${ema21:,.4f}
RSI (14): {rsi:.1f}
Recent high: ${max(highs):,.4f}
Recent low:  ${min(lows):,.4f}

Trading profile: Moderate risk, $500 budget, 12% per trade max.

Respond in this exact JSON format only:
{{"action": "buy" or "sell" or "hold", "confidence": 1-10, "reason": "one sentence"}}"""

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=150,
        messages=[{"role": "user", "content": prompt}]
    )

    text = response.content[0].text.strip()
    try:
        clean = text.replace("```json", "").replace("```", "").strip()
        data  = json.loads(clean)
        return data.get("action", "hold"), data.get("reason", "")
    except Exception:
        return "hold", text

# ── Logging ─────────────────────────────────────────────────────────────────────
def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

# ── Main Loop ────────────────────────────────────────────────────────────────────
def main():
    mode = "PAPER" if PAPER_MODE else "LIVE"
    log(f"Claude AI Trading Bot started — {mode} MODE")
    log(f"Watching: {', '.join(COINS)} | Budget: ${TRADE_BUDGET} | Interval: {CHECK_INTERVAL}s")

    while True:
        log("── Starting analysis cycle ──")
        for coin in COINS:
            try:
                price   = get_price(coin)
                candles = get_candles(coin)
                action, reason = analyze_with_claude(coin, price, candles)

                log(f"{coin} @ ${price:,.4f} → {action.upper()} | {reason}")

                if action in ("buy", "sell"):
                    amount = TRADE_BUDGET * RISK_PER_TRADE
                    result = place_order(coin, action.upper(), amount)
                    log(f"Order placed: {result}")

            except Exception as e:
                log(f"Error on {coin}: {e}")

        log(f"Cycle complete. Sleeping {CHECK_INTERVAL}s...")
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
